//
//  UserViewModelTests.swift
//  TestAppOne
//
//  Created by Murali on 05/01/26.
//
import Foundation
@testable import TestAppOne
import XCTest

@MainActor
final class UserViewModelTests: XCTestCase {

    func testLoadUsersSuccess() async {
        let mockService = MockAPIService()
        let viewModel = UserViewModel(apiService: mockService)

        await viewModel.loadUsers()

        XCTAssertEqual(viewModel.users.count, 1)
        XCTAssertNil(viewModel.errorMessage)
        XCTAssertFalse(viewModel.isLoading)
    }

    func testLoadUsersFailure() async {
        let mockService = MockAPIService()
        mockService.shouldFail = true

        let viewModel = UserViewModel(apiService: mockService)

        await viewModel.loadUsers()

        XCTAssertNotNil(viewModel.errorMessage)
        XCTAssertTrue(viewModel.users.isEmpty)
    }
}
