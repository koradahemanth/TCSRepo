//
//  MockAPIService.swift
//  TestAppOne
//
//  Created by Murali on 05/01/26.
//

import Foundation
@testable import TestAppOne

final class MockAPIService: APIServiceProtocol {

    var shouldFail = false

    func fetchUsers() async throws -> [User] {
        if shouldFail {
            throw URLError(.badServerResponse)
        }

        return [
            User(id: 1, name: "Test User", email: "test@test.com")
        ]
    }
}
