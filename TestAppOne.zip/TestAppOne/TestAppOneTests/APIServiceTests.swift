//
//  APIServiceTests.swift
//  TestAppOne
//
//  Created by Murali on 05/01/26.
//

import Foundation
import XCTest
@testable import TestAppOne
final class APIServiceTests: XCTestCase {

    func testFetchUsersReturnsData() async throws {
        let service = APIService()
        let users = try await service.fetchUsers()

        XCTAssertFalse(users.isEmpty)
    }
}
