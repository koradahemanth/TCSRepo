//
//  User.swift
//  TestAppOne
//
//  Created by Murali on 05/01/26.
//

import Foundation

struct User: Codable, Equatable {
    let id: Int
    let name: String
    let email: String
}

