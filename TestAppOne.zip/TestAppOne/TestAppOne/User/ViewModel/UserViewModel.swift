//
//  UserViewModel.swift
//  TestAppOne
//
//  Created by Murali on 05/01/26.
//

import Foundation


@MainActor
final class UserViewModel {

    private let apiService: APIServiceProtocol

     var users: [User] = []
     var errorMessage: String?
     var isLoading = false

    init(apiService: APIServiceProtocol = APIService()) {
        self.apiService = apiService
    }

    func loadUsers() async {
        isLoading = true
        errorMessage = nil

        do {
            users = try await apiService.fetchUsers()
        } catch {
            errorMessage = "Failed to load users"
        }

        isLoading = false
    }
}
