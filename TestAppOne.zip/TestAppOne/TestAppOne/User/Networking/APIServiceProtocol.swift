//
//  NetworkingServiceProtocal.swift
//  TestAppOne
//
//  Created by Murali on 05/01/26.
//

import Foundation

protocol APIServiceProtocol {
    func fetchUsers() async throws -> [User]
}

