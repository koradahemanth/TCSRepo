//
//  AP.swift
//  TestAppOne
//
//  Created by Murali on 05/01/26.
//

import Foundation

final class APIService:APIServiceProtocol {
    func fetchUsers() async throws -> [User] {
        
        let url = URL(string: "https://jsonplaceholder.typicode.com/users")!

        let (data, response) =  try await URLSession.shared.data(from: url)
        
        
      
        guard let httpres = response as? HTTPURLResponse, httpres.statusCode == 200  else { throw URLError(.badServerResponse)
        }
        
       return  try JSONDecoder().decode([User].self, from: data)
        
        
    }
    
    
}

