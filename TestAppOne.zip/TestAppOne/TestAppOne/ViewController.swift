//
//  ViewController.swift
//  TestAppOne
//
//  Created by Murali on 05/01/26.
//

import UIKit

class ViewController: UIViewController {
    
    private let viewModel = UserViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Task {
            await self.viewModel.loadUsers()
            if let errorMessage = viewModel.errorMessage {
                print("error", errorMessage)
            }
            
            viewModel.users.forEach {
                print("\($0.name) ----- \($0.email)  ----- \($0.id)")
            }
            
        }
        // Do any additional setup after loading the view.
    }
    
    
}

